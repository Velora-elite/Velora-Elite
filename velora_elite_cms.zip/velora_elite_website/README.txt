VELORA ELITE - NETLIFY STATIC WEBSITE

Files: index.html, admin.html, assets/, netlify.toml

Publish: Extract this ZIP, then upload the extracted site folder contents to Netlify Deploy manually. Keep the assets folder beside index.html.

WhatsApp orders go to +91 79053 17719. COD and UPI are offered; UPI payment is confirmed with the seller in WhatsApp. Razorpay is not included in this version.

Admin: open /admin.html. First visit lets you set a demo email/password. The admin can add/edit/delete products, prices, discount/MRP, descriptions, photos, stock, sizes, colours, and store settings.

IMPORTANT LIMITATION: This is a static no-backend version. Admin login is not secure and edits are saved only in that browser's local storage. They do NOT automatically update the storefront for other customers/devices, and the admin cannot see customer orders/sales across devices. For genuine shared live admin with secure email login and central order/sales records, a CMS/backend is required.

Custom design upload: customer selects a file, but the image must be attached manually in WhatsApp; the file is not uploaded to a server.
