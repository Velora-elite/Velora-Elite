VELORA ELITE — WhatsApp design sharing update

This update tries to share the selected custom-design image together with the order text using the phone/browser share sheet when supported. Customer chooses WhatsApp and confirms sending.
If file sharing is unsupported, WhatsApp opens with the order text and the customer is instructed to attach the design image manually.
Websites cannot silently send or attach WhatsApp messages. Automatic business messaging requires an authorized WhatsApp Business Platform/API backend.
Replace the repository-root index.html, commit changes, and wait for Netlify to publish.
